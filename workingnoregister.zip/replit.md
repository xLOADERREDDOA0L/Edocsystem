# eDocs Control — Engineering Document Control System

Smart engineering document control & distribution: upload → review → approval → revision control → controlled printing with QR codes → public QR verification → full audit trail. Thesis project; school requires Python/Flask.

## Run & Operate

- Backend (Flask, **the active backend**): `python flask-server/app.py` (port 8080; on Replit it runs via the "API Server" workflow)
- Frontend: `pnpm --filter @workspace/edocs run dev`
- Seed/reset DB: `cd flask-server && python seed.py` (delete `edocs.db` first for a full reset)
- Local one-command setup: `python setup.py` (see `LOCAL_SETUP.md`)
- Legacy Node backend (dormant, kept for reference): `pnpm --filter @workspace/api-server run dev`

## Stack

- Backend: Python Flask + Flask-SQLAlchemy + SQLite (`flask-server/edocs.db`), PyJWT (HS256, 8h), bcrypt
- Frontend: React + Vite (`artifacts/edocs`), wouter, shadcn, Orval-generated React Query client (unchanged from Express era)
- File storage: local disk `flask-server/.data/uploads/`
- Legacy: Express 5 + Drizzle + PostgreSQL in `artifacts/api-server` + `lib/db` (no longer used)

## Where things live

- Flask routes: `flask-server/routes_*.py` (one module per API area); models in `models.py`; auth/serializers in `helpers.py`
- Frontend pages: `artifacts/edocs/src/pages/`
- Setup docs: `LOCAL_SETUP.md`, `flask-server/README.md`

## Architecture decisions

- Flask replicates the Express API 1:1 so the generated frontend client works unchanged
- Requests list endpoint returns `{data: [...]}` (frontend reads `.data`); submitted revisions get status `under_review` (frontend's approve buttons key off it)
- QR tokens: `uuid4().hex`, exact DB match, no expiry; public verify at `/api/verify/<token>`
- JWT payload `{sub: str(userId)}`; storage routes verify signature only

## Product

Six roles: Administrator, Document Controller, Engineer, Supervisor, Employee, Inspector. Seed accounts: ADMIN001/Admin@1234, others (DC001, ENG001, SUP001, EMP001, INS001) with Password@123.

## User preferences

- User is a novice (Windows, PowerShell, VS Code) — plain language, step-by-step commands
- School requires Python/Flask — all new backend work goes in `flask-server/`
- User periodically downloads `edocs-system.zip` to run locally — rebuild it after significant changes

## Gotchas

- Workflow commands run from the artifact dir — use absolute paths for files outside it
- Sample credentials panel on the login page is dev-only (`TEMP` marker) — remove before final presentation
- `flask-server/edocs.db`, `.data/`, `__pycache__` are gitignored and excluded from the zip

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
