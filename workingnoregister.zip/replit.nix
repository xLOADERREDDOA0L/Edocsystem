{pkgs}: {
  deps = [
    pkgs.mesa
    pkgs.systemd
    pkgs.libxkbcommon
    pkgs.libdrm
    pkgs.at-spi2-core
    pkgs.alsa-lib
    pkgs.expat
    pkgs.cairo
    pkgs.pango
    pkgs.dbus
    pkgs.cups
    pkgs.xorg.libxcb
    pkgs.xorg.libXrandr
    pkgs.xorg.libXfixes
    pkgs.xorg.libXext
    pkgs.xorg.libXdamage
    pkgs.xorg.libXcomposite
    pkgs.xorg.libX11
    pkgs.at-spi2-atk
    pkgs.atk
    pkgs.nspr
    pkgs.nss
    pkgs.glib
  ];
}
