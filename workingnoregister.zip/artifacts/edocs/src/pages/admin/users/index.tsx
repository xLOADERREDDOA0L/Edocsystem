import { useState } from "react";
import { useListUsers, useDisableUser, useEnableUser } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, UserX, UserCheck, ShieldOff } from "lucide-react";
import { toast } from "sonner";
import { formatDate } from "@/lib/format";
import { useAuth } from "@/contexts/AuthContext";

const ALLOWED_ROLES = ["administrator", "document_controller", "supervisor"];

export default function UsersList() {
  const { user } = useAuth();
  const [page, setPage] = useState(1);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data, isLoading, refetch } = useListUsers({}, { query: { enabled: ALLOWED_ROLES.includes(user?.role ?? "") } as any });
  const disableMut = useDisableUser();
  const enableMut = useEnableUser();

  if (!ALLOWED_ROLES.includes(user?.role ?? "")) {
    return (
      <div className="flex h-[60vh] flex-col items-center justify-center text-center space-y-4">
        <ShieldOff className="w-12 h-12 text-muted-foreground" />
        <div className="text-2xl font-mono font-bold text-muted-foreground">ACCESS RESTRICTED</div>
        <p className="text-muted-foreground max-w-md text-sm">
          User Management is only accessible to Administrators, Document Controllers, and Supervisors.
        </p>
      </div>
    );
  }

  const handleToggleStatus = async (id: number, currentStatus: string) => {
    try {
      if (currentStatus === 'active') {
        await disableMut.mutateAsync({ id });
        toast.success("User disabled");
      } else {
        await enableMut.mutateAsync({ id });
        toast.success("User enabled");
      }
      refetch();
    } catch (err: any) {
      toast.error("Operation failed", { description: err.message });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">User Management</h1>
          <p className="text-muted-foreground mt-1 text-sm font-mono uppercase tracking-wider">System access control</p>
        </div>
        <Button asChild>
          <Link href="/admin/users/new"><Plus className="w-4 h-4 mr-2" /> NEW USER</Link>
        </Button>
      </div>

      <Card>
        <CardHeader className="border-b bg-slate-50 pb-4">
          <CardTitle className="text-sm font-bold uppercase tracking-wider">System Accounts</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[120px]">EMP ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Department</TableHead>
                <TableHead className="w-[100px]">Status</TableHead>
                <TableHead className="w-[150px]">Last Login</TableHead>
                <TableHead className="text-right w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 font-mono text-xs">LOADING...</TableCell></TableRow>
              ) : data?.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-12 text-muted-foreground font-mono text-xs">NO USERS FOUND</TableCell></TableRow>
              ) : (
                data?.map((u: any) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-mono font-bold text-xs">{u.employeeId}</TableCell>
                    <TableCell>
                      <div className="font-medium text-slate-900">{u.fullName}</div>
                      <div className="text-xs text-slate-500">{u.email}</div>
                    </TableCell>
                    <TableCell className="text-xs font-mono uppercase tracking-wider text-slate-600">
                      {u.role.replace("_", " ")}
                    </TableCell>
                    <TableCell className="text-xs">{u.departmentName || "-"}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`font-mono text-[10px] uppercase tracking-wider ${u.status === 'active' ? 'bg-emerald-100 text-emerald-800 border-emerald-200' : 'bg-red-100 text-red-800 border-red-200'}`}>
                        {u.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{formatDate(u.lastLogin)}</TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleToggleStatus(u.id, u.status)}
                        title={u.status === 'active' ? 'Disable User' : 'Enable User'}
                        className={u.status === 'active' ? 'text-red-500 hover:text-red-600 hover:bg-red-50' : 'text-emerald-500 hover:text-emerald-600 hover:bg-emerald-50'}
                      >
                        {u.status === 'active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}